$(function() {

	// Custom JS
  var num;

  $('.button-count:first-child').click(function(){
    num = parseInt($('.number-product').val());
    if (num > 1) {
      $('.number-product').val(num - 1);
      console.log('123');
    }
    if (num == 2) {
      $('.button-count:first-child').prop('disabled', true);
      console.log('123');
    }
    if (num == 10) {
      $('.button-count:last-child').prop('disabled', false);
      console.log('123');
    }
  });

  $('.button-count:last-child').click(function(){
    num = parseInt($('.number-product').val());
    if (num < 10) {
      console.log('123');
    }
    if (num > 0) {
      $('.button-count:first-child').prop('disabled', false);
      console.log('123');
    }
    if (num == 9) {
      $('.button-count:last-child').prop('disabled', true);
      console.log('123');
    }
  });
  //Modal
  $('.avatar,.close-swipe').click(function(event){
    $('.modal-mobile,.overlay').toggleClass('active');
    $('body').toggleClass('lock');
  });
  $('.personal-name').click(function(event){
    $('.personal-menu').toggleClass('active');
  });
  //Progress bar bottom  
  var $pc = $('.progress-pie-chart'),
  percent = parseInt($pc.data('percent')),
  deg = 360*percent/1000;
  if (percent > 500) {
    $pc.addClass('gt-50');
  }
  $('.ppc-progress-fill').css('transform','rotate('+ deg +'deg)');
  $('.ppc-percents span').html(percent+'%');

  $('.like').click(function(event){
    $(this).toggleClass('active');
  });
  $('.share').click(function(event){
    $(this).toggleClass('active');
    $(this).parent('.share-social-menu').toggleClass('active');
  });
  $('.login-language').click(function(event){
    $('.login-language').toggleClass('active');
    $('.overlay-personal').toggleClass('active');
  });
$("input:radio:checked").next('label').addClass("checked");
var checkBoxes = $('.check');
checkBoxes.change(function () {
    $('#submitBtn').prop('disabled', checkBoxes.filter(':checked').length < 1);
});

checkBoxes.change(); 
var swiper = new Swiper('.swiper-container', {
      slidesPerView: 'auto',
      mode:'horizontal',

      centeredSlides: true,
      spaceBetween: 40,
      pagination: false,
      loop: true
    });
 var swiper = new Swiper('.swiper-container-recently', {
      slidesPerView: 6,
      spaceBetween: 83,
      centeredSlides: true,
      loop: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      }
    });
//Password exist
$('.password').on('keyup', function()
{
    var self = $( this ),
    link = self.siblings('.input-wrapper a');
    if ( self.val() != '' ) {
        link.addClass('hidden')
    } else {
         link.removeClass('hidden')
    }
});
});
